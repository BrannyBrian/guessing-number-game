import sys
import random
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton

class GuessNumberGame(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Guess the Number Game')
        self.setGeometry(100, 100, 300, 200)

        # Layout
        self.layout = QVBoxLayout()

        # Instructions label
        self.label = QLabel('Guess a number between 1 and 100:', self)
        self.layout.addWidget(self.label)

        # Input field for guess
        self.input_field = QLineEdit(self)
        self.layout.addWidget(self.input_field)

        # Submit button
        self.submit_btn = QPushButton('Submit Guess', self)
        self.layout.addWidget(self.submit_btn)

        # Feedback label
        self.feedback_label = QLabel('', self)
        self.layout.addWidget(self.feedback_label)

        # Connect button click to check_guess function
        self.submit_btn.clicked.connect(self.check_guess)

        # Set layout
        self.setLayout(self.layout)

        # Random target number and attempts
        self.target_number = random.randint(1, 100)
        self.attempts = 0

    def check_guess(self):
        try:
            guess = int(self.input_field.text())  # Get user input and convert to int
        except ValueError:
            self.feedback_label.setText('Please enter a valid number.')
            return

        self.attempts += 1

        if guess < self.target_number:
            self.feedback_label.setText('Too low! Try again.')
        elif guess > self.target_number:
            self.feedback_label.setText('Too high! Try again.')
        else:
            self.feedback_label.setText(f'Correct! You guessed it in {self.attempts} attempts.')
            self.submit_btn.setEnabled(False)  # Disable further guessing after the correct answer


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = GuessNumberGame()
    window.show()
    sys.exit(app.exec_())
